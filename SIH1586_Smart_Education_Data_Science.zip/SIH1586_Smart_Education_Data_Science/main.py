from pathlib import Path
import sys
import pandas as pd

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))
from education_model import load_dataset, load_or_train, train_and_evaluate, NUMERIC_FEATURES, CATEGORICAL_FEATURES
from recommendation import recommend_learning_plan

def get_student_row(df, learner_id):
    found = df[df["learner_id"].str.upper() == learner_id.strip().upper()]
    if found.empty:
        raise ValueError(f"Learner ID '{learner_id}' was not found in the included synthetic dataset.")
    return found.iloc[0]

def main():
    print("=" * 70)
    print("SIH1586: SMART EDUCATION — PERSONALIZED LEARNING ANALYTICS")
    print("Command-line demonstration | Synthetic educational dataset")
    print("=" * 70)
    df = load_dataset()
    model_path = ROOT / "outputs" / "smart_education_model.joblib"
    if not model_path.exists():
        print("\nNo trained model found. Training model now...")
        _, metrics, report = train_and_evaluate()
        print(report)
    model = load_or_train()

    learner_id = input("\nEnter a sample learner ID (e.g., L0007) or type RANDOM: ").strip()
    if learner_id.upper() == "RANDOM":
        row = df.sample(n=1, random_state=18).iloc[0]
    else:
        row = get_student_row(df, learner_id)

    features = row[NUMERIC_FEATURES + CATEGORICAL_FEATURES].to_frame().T
    prediction = model.predict(features)[0]
    probabilities = model.predict_proba(features)[0]
    classes = model.named_steps["classifier"].classes_
    probability_map = {str(c): float(p) for c, p in zip(classes, probabilities)}

    print("\n--- LEARNER PROFILE (SYNTHETIC EXAMPLE) ---")
    print(f"Learner ID: {row['learner_id']}")
    print(f"Topic: {row['topic']}")
    print(f"Learning style: {row['learning_style']}")
    print(f"Weekly study hours: {row['weekly_study_hours']}")
    print(f"Attendance: {row['attendance_pct']}%")
    print(f"Course completion: {row['course_completion_pct']}%")
    print(f"Latest quiz score: {row['latest_quiz_score_pct']}%")
    print(f"Missed deadlines: {row['missed_deadlines']}")

    print("\n--- MODEL OUTPUT ---")
    print(f"Predicted support status: {prediction.upper()}")
    print("Model class scores (not guaranteed calibrated):")
    for cls, prob in probability_map.items():
        print(f"  {cls}: {prob:.1%}")

    print("\n--- PERSONALIZED STUDY PLAN ---")
    for i, item in enumerate(recommend_learning_plan(row), start=1):
        print(f"{i}. {item}")

    print("\n--- EXPLANATION ---")
    reasons = []
    if float(row["latest_quiz_score_pct"]) < 50: reasons.append("low latest quiz score")
    if float(row["attendance_pct"]) < 75: reasons.append("attendance below 75%")
    if float(row["course_completion_pct"]) < 60: reasons.append("course completion below 60%")
    if int(row["missed_deadlines"]) >= 3: reasons.append("three or more missed deadlines")
    if float(row["weekly_study_hours"]) < 2: reasons.append("less than two study hours per week")
    if reasons:
        print("Indicators to review: " + ", ".join(reasons) + ".")
    else:
        print("No listed high-priority rule was triggered; continue regular revision and monitor progress.")
    print("\nIMPORTANT: This is a synthetic demonstration, not an official student assessment.")
    print("Do not use predictions to grade, punish, or make high-stakes decisions about real learners.")

if __name__ == "__main__":
    main()
