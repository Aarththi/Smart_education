# SIH1586 — Smart Education: Personalized Learning Analytics

**Exact selected problem statement**
- **Statement ID:** SIH1586
- **Title:** Student Innovation
- **Category:** Software
- **Technology bucket:** Smart Education
- **Description supplied:** “Smart Education, a Concept that Describes learning in digital age.it enables learner to learn more effectively,efficently,flexibly and comfortably.”
- **Department:** AICTE
- **Organisation:** AICTE, MIC-Student Innovation
- **Datasetfile:** NULL

This implementation uses the supplied broad Smart Education problem statement. It is a data-science prototype, not a claim that the source statement specified these exact algorithms.

## Project idea
A command-line Smart Education analytics prototype that estimates whether a learner may need additional academic support and suggests a study plan based on learning indicators and learning style.

## What is included
- 600-row synthetic dataset
- Exploratory data analysis (EDA)
- Missing-value handling and categorical encoding
- Standardization of numeric features
- Random Forest classifier
- Train/test split with stratification
- Accuracy, macro precision, macro recall, macro F1, classification report, confusion matrix
- Rule-based personalized study recommendations
- Explanation of indicators that trigger suggestions
- No graphical UI

## Dataset
`data/smart_education_synthetic_dataset.csv`

The data is synthetically generated for demonstration; it is not collected from actual students. The support label is generated from simulated rules and indicators, so high metrics do not prove real-world effectiveness. The dataset contains 600 records with features including study hours, attendance, course completion, quiz scores, assignment completion, missed deadlines, learning style, and topic.

## Run in VS Code / Windows
Use Python 3.10 or 3.11 if possible.

```bash
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
```

### Step 1 — Explore data and train model
```bash
python src/analyze.py
```
This prints dataset summaries and model evaluation. It saves the trained model and evaluation reports in `outputs/`.

### Step 2 — Run interactive demonstration
```bash
python main.py
```
Enter a dataset learner ID such as `L0007`, or type `RANDOM`.

### Step 3 — Evaluate model only
```bash
python src/education_model.py
```

## Sample IDs
`L0001` to `L0600`.

## Project structure
```text
SIH1586_Smart_Education_Data_Science/
├── data/
│   └── smart_education_synthetic_dataset.csv
├── src/
│   ├── education_model.py
│   ├── recommendation.py
│   └── analyze.py
├── outputs/                 # reports/model created when run
├── main.py
├── requirements.txt
├── report.md
├── TEAM_DIVISION.md
├── GITHUB_STEPS.md
└── .gitignore
```

## Limitations and ethical use
- Synthetic data is only suitable for demonstrating the pipeline.
- The predicted support label is not a diagnosis or a reliable assessment of a real student.
- Do not use this system for grading, disciplinary action, admissions, or other high-stakes decisions.
- A real deployment would need consent, privacy safeguards, representative approved data, validation with educators, and bias/error analysis.
