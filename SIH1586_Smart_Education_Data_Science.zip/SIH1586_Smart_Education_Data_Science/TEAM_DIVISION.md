# Work division for a 2-member team

## Member 1 — Dataset and machine-learning pipeline
- Understand the SIH1586 Smart Education theme.
- Generate and inspect the synthetic dataset.
- Perform EDA and preprocessing.
- Train the Random Forest model.
- Run evaluation and explain accuracy, precision, recall, F1-score, and confusion matrix.
- Maintain `data/smart_education_synthetic_dataset.csv` and `src/education_model.py`.

## Member 2 — Personalized recommendations and project integration
- Implement the recommendation rules in `src/recommendation.py`.
- Integrate the model with the command-line demonstration in `main.py`.
- Test several sample learner IDs and document outputs.
- Prepare report, README, GitHub repository, and ZIP submission.

## Shared tasks
- Both members should understand the problem statement, dataset fields, model workflow, limitations, and results.
- Test the code together before submission.
- Do not claim the synthetic results represent real student performance.
