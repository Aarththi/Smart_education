from pathlib import Path
import sys
import pandas as pd
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from education_model import load_dataset, train_and_evaluate, NUMERIC_FEATURES, CATEGORICAL_FEATURES

def main():
    df = load_dataset()
    print("=" * 68)
    print("SIH1586 — SMART EDUCATION DATA SCIENCE ANALYSIS")
    print("=" * 68)
    print(f"\nDataset shape: {df.shape[0]} records × {df.shape[1]} columns")
    print("\nFirst 5 records:")
    print(df.head().to_string(index=False))
    print("\nMissing values per column:")
    print(df.isna().sum().to_string())
    print("\nSupport-status distribution:")
    print(df["support_status"].value_counts().to_string())
    print("\nNumeric feature summary:")
    print(df[NUMERIC_FEATURES].describe().round(2).to_string())
    print("\nAverage indicators by support status:")
    print(df.groupby("support_status")[[
        "weekly_study_hours", "attendance_pct", "course_completion_pct",
        "latest_quiz_score_pct", "missed_deadlines"
    ]].mean().round(2).to_string())

    _, metrics, report = train_and_evaluate()
    print("\n" + report)
    print("Analysis and evaluation reports saved in outputs/")

if __name__ == "__main__":
    main()
