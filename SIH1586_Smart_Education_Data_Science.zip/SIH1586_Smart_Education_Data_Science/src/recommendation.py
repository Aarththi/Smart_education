"""Transparent personalized study recommendations."""
def recommend_learning_plan(student):
    plan = []
    # Prioritize immediate support from observable learning indicators.
    if float(student["latest_quiz_score_pct"]) < 50:
        plan.append("Review the topic notes, then complete 5 easy practice questions before retrying a quiz.")
    elif float(student["latest_quiz_score_pct"]) < 70:
        plan.append("Revise the most recent topic and complete 10 mixed practice questions.")
    else:
        plan.append("Maintain progress with one challenging question set and a short weekly revision.")

    if float(student["attendance_pct"]) < 75:
        plan.append("Improve attendance and ask the course instructor for missed-topic materials.")
    if float(student["course_completion_pct"]) < 60:
        plan.append("Break unfinished course content into 20–30 minute study sessions and track completion.")
    if int(student["missed_deadlines"]) >= 3:
        plan.append("Use a weekly deadline checklist and set reminders at least one day before due dates.")
    if float(student["weekly_study_hours"]) < 2:
        plan.append("Start with four focused 25-minute study blocks per week, then adjust based on progress.")

    style = str(student["learning_style"]).lower()
    style_resources = {
        "visual": "Use diagrams, mind maps, and labelled concept maps.",
        "reading": "Use concise notes, worked examples, and self-explanation summaries.",
        "practice": "Learn through small exercises, quizzes, and immediate error review.",
        "video": "Watch short topic videos and pause to write a 3-point summary."
    }
    plan.append(f"Learning-style suggestion: {style_resources.get(style, 'Try notes, videos, and practice questions to find what works best.')}")
    plan.append(f"Topic focus: schedule one focused revision session for {student['topic'].replace('_', ' ')}.")
    return plan
