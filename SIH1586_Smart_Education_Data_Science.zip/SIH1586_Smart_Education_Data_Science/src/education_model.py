from pathlib import Path
import json
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report, confusion_matrix

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "smart_education_synthetic_dataset.csv"
MODEL_PATH = ROOT / "outputs" / "smart_education_model.joblib"
METRICS_PATH = ROOT / "outputs" / "evaluation_report.json"
TEXT_REPORT_PATH = ROOT / "outputs" / "evaluation_report.txt"

NUMERIC_FEATURES = [
    "age", "weekly_study_hours", "attendance_pct", "course_completion_pct",
    "previous_score_pct", "latest_quiz_score_pct", "assignments_completed",
    "missed_deadlines"
]
CATEGORICAL_FEATURES = ["learning_style", "topic"]
TARGET = "support_status"

def load_dataset():
    df = pd.read_csv(DATA_PATH)
    required = NUMERIC_FEATURES + CATEGORICAL_FEATURES + [TARGET]
    missing = [col for col in required if col not in df.columns]
    if missing:
        raise ValueError(f"Dataset is missing columns: {missing}")
    return df

def build_pipeline():
    numeric_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])
    categorical_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore"))
    ])
    prep = ColumnTransformer([
        ("numeric", numeric_pipe, NUMERIC_FEATURES),
        ("categorical", categorical_pipe, CATEGORICAL_FEATURES)
    ])
    model = RandomForestClassifier(
        n_estimators=250,
        class_weight="balanced",
        random_state=42,
        min_samples_leaf=2
    )
    return Pipeline([("preprocess", prep), ("classifier", model)])

def train_and_evaluate():
    df = load_dataset()
    X = df[NUMERIC_FEATURES + CATEGORICAL_FEATURES]
    y = df[TARGET]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
    pipeline = build_pipeline()
    pipeline.fit(X_train, y_train)
    preds = pipeline.predict(X_test)
    metrics = {
        "dataset": "Synthetic Smart Education Dataset",
        "total_records": int(len(df)),
        "train_records": int(len(X_train)),
        "test_records": int(len(X_test)),
        "target_classes": sorted(y.unique().tolist()),
        "accuracy": float(accuracy_score(y_test, preds)),
        "precision_macro": float(precision_score(y_test, preds, average="macro", zero_division=0)),
        "recall_macro": float(recall_score(y_test, preds, average="macro", zero_division=0)),
        "f1_macro": float(f1_score(y_test, preds, average="macro", zero_division=0)),
        "classification_report": classification_report(y_test, preds, zero_division=0, output_dict=True),
        "confusion_matrix": confusion_matrix(y_test, preds, labels=["needs_support", "on_track"]).tolist(),
        "confusion_matrix_labels": ["needs_support", "on_track"],
        "note": "Synthetic data and labels; evaluation measures this generated dataset only, not real student outcomes."
    }
    import joblib
    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(pipeline, MODEL_PATH)
    METRICS_PATH.write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    report = (
        "SIH1586 SMART EDUCATION — EVALUATION REPORT\n"
        "===========================================\n"
        f"Dataset records: {len(df)}\nTraining records: {len(X_train)}\nTest records: {len(X_test)}\n"
        f"Accuracy: {metrics['accuracy']:.3f}\n"
        f"Macro precision: {metrics['precision_macro']:.3f}\n"
        f"Macro recall: {metrics['recall_macro']:.3f}\n"
        f"Macro F1-score: {metrics['f1_macro']:.3f}\n\n"
        "Classification report:\n"
        f"{classification_report(y_test, preds, zero_division=0)}\n"
        "Confusion matrix (rows=true, columns=predicted; needs_support, on_track):\n"
        f"{metrics['confusion_matrix']}\n\n"
        "LIMITATION: all records and labels are synthetic. These results are not evidence of real-world student prediction accuracy.\n"
    )
    TEXT_REPORT_PATH.write_text(report, encoding="utf-8")
    return pipeline, metrics, report

def load_or_train():
    if MODEL_PATH.exists():
        import joblib
        return joblib.load(MODEL_PATH)
    model, _, _ = train_and_evaluate()
    return model

if __name__ == "__main__":
    _, metrics, report = train_and_evaluate()
    print(report)
    print(f"Saved model: {MODEL_PATH}")
    print(f"Saved report: {TEXT_REPORT_PATH}")
