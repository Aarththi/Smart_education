# Project Report: SIH1586 — Smart Education

## 1. Problem statement
**Statement ID:** SIH1586  
**Title:** Student Innovation  
**Category:** Software  
**Technology bucket:** Smart Education  

**Description supplied in the problem-statement record:** “Smart Education, a Concept that Describes learning in digital age.it enables learner to learn more effectively,efficently,flexibly and comfortably.”

The record lists `Datasetfile` as `NULL`. Therefore, this project creates a synthetic dataset to demonstrate data-science concepts.

## 2. Aim
To demonstrate how learner activity indicators can be analysed to identify simulated learners who may need extra support and to provide simple personalized study suggestions.

## 3. Objectives
- Create a reproducible synthetic educational dataset.
- Explore learner indicators and target-class distribution.
- Preprocess numeric and categorical data.
- Train a machine-learning classifier.
- Evaluate predictions on a held-out test set.
- Generate personalized study recommendations from learner indicators and stated learning style.
- Provide a no-UI, terminal-based demonstration.

## 4. Dataset description
The CSV contains 600 synthetic records. Fields include learner ID, age, learning style, topic, weekly study hours, attendance percentage, course completion percentage, previous score, latest quiz score, assignments completed, missed deadlines, and simulated support status. No real student records are used.

## 5. Methodology
1. Read the CSV using pandas.
2. Inspect dataset dimensions, missing values, class counts, numeric summaries, and group means.
3. Split the data into training (75%) and testing (25%) with stratification.
4. Impute numeric missing values with the median and categorical values with the most frequent category.
5. Standardize numeric features and one-hot encode categorical features.
6. Train a Random Forest classifier.
7. Evaluate using accuracy, macro precision, macro recall, macro F1-score, classification report, and confusion matrix.
8. Predict a selected synthetic learner's support status.
9. Recommend a study plan using quiz score, attendance, completion, deadlines, weekly study hours, topic, and learning style.

## 6. Data science concepts
- Synthetic data generation
- Exploratory data analysis
- Data preprocessing
- Missing-value imputation
- Feature scaling
- One-hot encoding
- Supervised classification
- Random Forest
- Stratified train/test split
- Classification metrics and confusion matrix
- Recommendation rules based on learner attributes

## 7. Innovation
The prototype combines a model-based support-status prediction with a separate recommendation layer. Suggestions are connected to observable learning indicators and the learner's selected learning style. The program also prints a short explanation of the indicators to review. This is intended as a transparent learning-support demonstration, not as a decision-making system for actual students.

## 8. Results
Run `python src/analyze.py` to generate the real evaluation results in `outputs/evaluation_report.txt` and `outputs/evaluation_report.json`. Insert the metrics from that run into the submitted report. Since labels are generated synthetically from rules, the score is only a technical check of the pipeline and must not be presented as real-world accuracy.

## 9. Limitations
The dataset is synthetic, small, and generated from assumptions. Real students' learning needs are more complex. The model can reflect the synthetic label-generation rule rather than general patterns in education. It has not been validated on real student data.

## 10. Future scope
- Work with consented, anonymized, institution-approved data.
- Validate recommendations with educators and students.
- Compare Random Forest with Logistic Regression and Gradient Boosting.
- Use cross-validation and calibration on a separate validation set.
- Study fairness and error rates across relevant groups.
- Add verified learning resources and multilingual content.

## 11. Conclusion
This project demonstrates an end-to-end data-science workflow for the broad SIH1586 Smart Education theme: synthetic data generation, EDA, preprocessing, supervised learning, evaluation, and personalized recommendations. It is a runnable prototype and needs real-world validation before any educational deployment.
